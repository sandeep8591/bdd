package com.cg.hotel.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class BookingPage {

	WebDriver driver;
	
	@FindBy(how=How.NAME, using="fname")
	@CacheLookup
	private WebElement fname;
	
	@FindBy(how=How.NAME, using="lname")
	@CacheLookup
	private WebElement lname;
	
	@FindBy(how=How.NAME, using="mobile")
	@CacheLookup
	private WebElement mobile;
	
	@FindBy(how=How.NAME, using="email")
	@CacheLookup
	private WebElement email;
	
	@FindBy(how=How.NAME, using="address")
	@CacheLookup
	private WebElement address;
	
	@FindBy(how=How.NAME, using="suite")
	@CacheLookup
	private WebElement suite;
	
	@FindBy(how=How.NAME, using="arrivalDate")
	@CacheLookup
	private WebElement arrivalDate;
	
	@FindBy(how=How.NAME, using="duration")
	@CacheLookup
	private WebElement duration;

	@FindBy(how=How.NAME, using="book")
	@CacheLookup
	private WebElement book;
	
	public WebElement getBook() {
		return book;
	}

	public void setBook() {
		this.book.click();
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getSuite() {
		return suite;
	}

	public void setSuite(String suite) {
		Select suiteDrop=new Select(this.suite);
		suiteDrop.selectByValue(suite);
	}

	public WebElement getArrivalDate() {
		return arrivalDate;
	}

	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate.sendKeys(arrivalDate);
	}

	public WebElement getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration.sendKeys(duration);
	}
	
	
	
}
