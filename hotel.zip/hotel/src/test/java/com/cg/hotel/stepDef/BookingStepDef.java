package com.cg.hotel.stepDef;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.factory.BrowserFactory;
import com.cg.hotel.pages.BookingPage;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookingStepDef {

	WebDriver driver;
	BookingPage bPage;

	@Before
	public void setUp() {

	}

	@Given("^user is on booking page$")
	public void user_is_on_booking_page() throws Throwable {

		driver = BrowserFactory.startBrowser("chrome",
				"C:\\Users\\anraipur\\Desktop\\Module4\\hotel\\src\\test\\java\\com\\cg\\hotel\\html\\bookHotel.html");
		driver.manage().timeouts().implicitlyWait(360, TimeUnit.SECONDS);
		bPage = PageFactory.initElements(driver, BookingPage.class);
		Thread.sleep(1000);
	}

	@Given("^enter fname$")
	public void enter_fname() throws Throwable {
		bPage.setFname("Anuja");
	}

	@Given("^enter lname$")
	public void enter_lname() throws Throwable {
		bPage.setLname("Raipure");
	}

	@Given("^enter mobile$")
	public void enter_mobile() throws Throwable {
		bPage.setMobile("8087864923");
	}

	@Given("^enter email$")
	public void enter_email() throws Throwable {
		bPage.setEmail("anuja.raipure@gmail.com");
	}

	@Given("^enter address$")
	public void enter_address() throws Throwable {
		bPage.setAddress("4 Prince of Wales Drive, Wanowarie, Pune");
	}

	@Given("^enter suite type$")
	public void enter_suite_type() throws Throwable {
		try {
		bPage.setSuite("king");
		}
		catch(Exception e) {
			driver.close();
		}
	}

	@Given("^enter arrivaldate$")
	public void enter_arrivaldate() throws Throwable {
		bPage.setArrivalDate("05/15/2019");
	}

	@Given("^enter duration$")
	public void enter_duration() throws Throwable {
		bPage.setDuration("4");
	}

	@Given("^click on book button$")
	public void click_on_book_button() throws Throwable {
		bPage.setBook();
	}

	@When("^alert box shows$")
	public void alert_box_shows() throws Throwable {

		driver.switchTo().alert();
		Thread.sleep(1000);
	}

	@When("^accept alert$")
	public void accept_alert() throws Throwable {
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@Then("^close the page display successfull message$")
	public void close_the_page_display_successfull_message() throws Throwable {
		System.out.println("Succesfull");
		Thread.sleep(1000);
		driver.close();
	}

	@Then("^display next page$")
	public void display_next_page() throws Throwable {
		driver.get("C:\\Users\\anraipur\\Desktop\\Module4\\hotel\\src\\test\\java\\com\\cg\\hotel\\html\\successful.html");
	}

}
