package com.cg.hotel.stepDef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDef {

	WebDriver driver;

	@Given("^go to login page$")
	public void go_to_login_page() throws Throwable {

		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\anraipur\\Desktop\\Module4\\hotel\\src\\test\\java\\com\\cg\\hotel\\browser\\driver\\chromedriver.exe");
		driver = new ChromeDriver();

		driver.get("C:\\Users\\anraipur\\Desktop\\Module4\\hotel\\src\\test\\java\\com\\cg\\hotel\\html\\login.html");
		Thread.sleep(1000);
	}

	@Given("^enter password$")
	public void enter_password() throws Throwable {
		driver.findElement(By.name("password")).sendKeys("Anuja123");
		Thread.sleep(1000);
	}

	@When("^click on login button$")
	public void click_on_login_button() throws Throwable {
		driver.findElement(By.name("login")).click();
		Thread.sleep(1000);
	}

	@When("^switch to alert$")
	public void switch_to_alert() throws Throwable {
		driver.switchTo().alert();
		Thread.sleep(1000);
	}

	@When("^accept alert1$")
	public void accept_alert1() throws Throwable {
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}

	@Then("^close driver$")
	public void close_driver() throws Throwable {
		driver.close();
	}

	@Given("^enter username$")
	public void enter_username() throws Throwable {
		driver.findElement(By.name("uname")).sendKeys("anuja.raipure");
		Thread.sleep(1000);
	}

	@Then("^check if booking form is open$")
	public void check_if_booking_form_is_open() throws Throwable {
		System.out.println("login successfull!");
	}

	@Given("^keep username and password empty$")
	public void keep_username_and_password_empty() throws InterruptedException {
		driver.findElement(By.name("uname")).sendKeys("");
		Thread.sleep(1000);
		driver.findElement(By.name("password")).sendKeys("");
		Thread.sleep(1000);
	}

	@Then("^close$")
	public void close() throws Throwable {
		driver.close();
	}

	@Given("^enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void enter_and(String arg1, String arg2) throws Throwable {
		driver.findElement(By.name("uname")).sendKeys(arg1);
		Thread.sleep(1000);
		driver.findElement(By.name("password")).sendKeys(arg2);
		Thread.sleep(1000);
	}

}
