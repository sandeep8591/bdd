package com.cg.hotel.test;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

/**
 * Unit test for simple App.
 */

@RunWith(Cucumber.class)
@CucumberOptions(features= {"C:\\Users\\anraipur\\Desktop\\Module4\\hotel\\features"},glue="com.cg.hotel.stepDef")
public class TestRunner {
    
}


/*@CucumberOptions(features= {"C:\\Users\\anraipur\\Desktop\\Module4\\hotel\\features\\loginFeatures.feature","C:\\Users\\anraipur\\Desktop\\Module4\\hotel\\features\\bookingFeatures.feature"},glue="com.cg.hote.stepDef.LoginStepDef")*/