package com.cg.hotel.pages;

public class LoginPage {

	
}
