$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/paranyIT/Desktop/Capgemini/JEE Full Stack/Module 4/BDD Programs/coaching/src/test/java/com/cg/coaching/feature/CoachingForm.feature");
formatter.feature({
  "line": 1,
  "name": "To test coaching enquiry form elements",
  "description": "this feature is for testing all the elements in the coaching enquiry form",
  "id": "to-test-coaching-enquiry-form-elements",
  "keyword": "Feature"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 10920466963,
  "status": "passed"
});
formatter.scenario({
  "line": 7,
  "name": "to verify the title of the page",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;to-verify-the-title-of-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 8,
  "name": "check the title of the page",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.check_the_title_of_the_page()"
});
formatter.result({
  "duration": 35330896,
  "status": "passed"
});
formatter.after({
  "duration": 2116043970,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9178887771,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "to verify the text on the page",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;to-verify-the-text-on-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "check if text is present",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.check_if_text_is_present()"
});
formatter.result({
  "duration": 101985924,
  "status": "passed"
});
formatter.after({
  "duration": 2101158436,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9373058973,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "check for alert if first name text box is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-first-name-text-box-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "fill form data except first name",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_first_name()"
});
formatter.result({
  "duration": 5157215073,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3106742157,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2019568624,
  "status": "passed"
});
formatter.after({
  "duration": 2120696339,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9605030859,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "check for alert if last name text box is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-last-name-text-box-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "fill form data except last name",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_last_name()"
});
formatter.result({
  "duration": 5178905813,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3090468860,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2015780802,
  "status": "passed"
});
formatter.after({
  "duration": 2205017304,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9304813332,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "check for alert if email is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-email-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "fill form data except email empty",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_email_empty()"
});
formatter.result({
  "duration": 5108938391,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3069979613,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2011214741,
  "status": "passed"
});
formatter.after({
  "duration": 2092640225,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 10196643428,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "check for alert if mobile is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-mobile-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "fill form data except mobile",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_mobile()"
});
formatter.result({
  "duration": 5069317427,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3110952744,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2013086221,
  "status": "passed"
});
formatter.after({
  "duration": 2164219715,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9267727985,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "check for alert if tuition type is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-tuition-type-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 34,
  "name": "fill form data except tuition type",
  "keyword": "Given "
});
formatter.step({
  "line": 35,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_tuition_type()"
});
formatter.result({
  "duration": 4547583045,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3090637088,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2011470253,
  "status": "passed"
});
formatter.after({
  "duration": 2548930823,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 14661709698,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "check for alert if city is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-city-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "fill form data except city",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 41,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_city()"
});
formatter.result({
  "duration": 4627318444,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3151614286,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2011673102,
  "status": "passed"
});
formatter.after({
  "duration": 2153636928,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 10043105975,
  "status": "passed"
});
formatter.scenario({
  "line": 43,
  "name": "check for alert if learning mode is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-learning-mode-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 44,
  "name": "fill form data except learning mode",
  "keyword": "Given "
});
formatter.step({
  "line": 45,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 46,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_learning_mode()"
});
formatter.result({
  "duration": 4502914740,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3115876229,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2013195936,
  "status": "passed"
});
formatter.after({
  "duration": 2142818133,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 9761924104,
  "status": "passed"
});
formatter.scenario({
  "line": 48,
  "name": "check for alert if enquiry is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-enquiry-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 49,
  "name": "fill form data except enquiry",
  "keyword": "Given "
});
formatter.step({
  "line": 50,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 51,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_enquiry()"
});
formatter.result({
  "duration": 4957369454,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3087186699,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2023755804,
  "status": "passed"
});
formatter.after({
  "duration": 2150957951,
  "status": "passed"
});
formatter.background({
  "line": 4,
  "name": "launch the coaching enquiry form",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 5,
  "name": "user is on coaching enquiry form",
  "keyword": "Given "
});
formatter.match({
  "location": "CoachingStepDef.user_is_on_coaching_enquiry_form()"
});
formatter.result({
  "duration": 10544432053,
  "status": "passed"
});
formatter.scenario({
  "line": 53,
  "name": "check for alert if city is empty",
  "description": "",
  "id": "to-test-coaching-enquiry-form-elements;check-for-alert-if-city-is-empty",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 54,
  "name": "fill form data except city",
  "keyword": "Given "
});
formatter.step({
  "line": 55,
  "name": "click on submit",
  "keyword": "And "
});
formatter.step({
  "line": 56,
  "name": "switch to alert and accept it",
  "keyword": "Then "
});
formatter.match({
  "location": "CoachingStepDef.fill_form_data_except_city()"
});
formatter.result({
  "duration": 4587381990,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.click_on_submit()"
});
formatter.result({
  "duration": 3111782183,
  "status": "passed"
});
formatter.match({
  "location": "CoachingStepDef.switch_to_alert_and_accept_it()"
});
formatter.result({
  "duration": 2008441654,
  "status": "passed"
});
formatter.after({
  "duration": 2176484299,
  "status": "passed"
});
});