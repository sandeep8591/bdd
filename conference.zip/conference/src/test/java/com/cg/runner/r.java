package com.cg.runner;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
@RunWith(Cucumber.class)
@CucumberOptions(
		features={"C:\\Users\\jsahith\\Desktop\\Bdd\\miplcasestudy-master\\MODULE4\\src\\test\\java\\com\\cg\\feature"}
		,glue= {"com.cg.stpdef"}
		//features="com.cg.feature",glue= {"com.cg.stepdef"}
		,plugin = {"pretty", "html:target/husain-report"}
		,monochrome=true
		,tags= {"@smoke"}		
//		,dryRun=true
		)
public class r
{    

}

 
